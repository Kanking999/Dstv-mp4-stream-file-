# josh-tv

This app visualizes a Plex media collection as a "TV Guide"-like schedule. [You can read more about it here](https://regexking.info/2023/12/14/josh-tv.html).

This is a native MacOS app which requires Xcode to build. The minimum requirements are "whatever Josh has", which in this case means:

- a somewhat recent MacOS version
- a Plex installation where the Plex sqlite database file can be found by your Mac

I haven't really tried building and running this on any computer but my own, so your mileage may vary.
